package network;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class Client extends JFrame {
    private double cash = 1000.0;
    private Map<String, Integer> holdings = new HashMap<>();
    private Map<String, Double> stockPrices = new HashMap<>();
    private String selectedStock = "AAPL";
    
    private String username;
    private DataOutputStream toServer;
    private DataInputStream fromServer;
    private JTextArea ta = new JTextArea(10, 30);
    // define button to control
    private JButton buyMenuBtn, sellMenuBtn, nextBtn, infoBtn, priceBtn, logBtn, chartBtn, compareChartBtn;
    private JMenuItem buyAllItem, buyPartItem, sellAllItem, sellPartItem;
    private JPopupMenu buyMenu, sellMenu;
    private JComboBox<String> stockSelector;
    
    private boolean tradingEnded = false;
    
    private Map<String, List<Double>> stockHistory = new HashMap<>();
    
    public Client() {
        super("Stock Client");
        setupUI();
        connectToServer();
    }
    
    private void setupUI() {
        setLayout(new BorderLayout());
        
        JPanel buttonPanel = new JPanel();
        JPanel topPanel = new JPanel();
        stockSelector = new JComboBox<>();
        stockSelector.addActionListener(e -> {
            selectedStock = (String) stockSelector.getSelectedItem();
            ta.append(" Selected stock: " + selectedStock + "\n");
        });
        topPanel.add(new JLabel("Stock:"));
        topPanel.add(stockSelector);
        
        buyMenuBtn = new JButton("Buy");
        buyMenu = new JPopupMenu();
        buyAllItem = new JMenuItem("Buy All");
        buyPartItem = new JMenuItem("Buy Partial");
        buyAllItem.addActionListener(e -> buyAll());
        buyPartItem.addActionListener(e -> buyPartial());
        buyMenu.add(buyAllItem);
        buyMenu.add(buyPartItem);
        buyMenuBtn.addActionListener(e -> buyMenu.show(buyMenuBtn, 0, buyMenuBtn.getHeight()));
        
        sellMenuBtn = new JButton("Sell");
        sellMenu = new JPopupMenu();
        sellAllItem = new JMenuItem("Sell All");
        sellPartItem = new JMenuItem("Sell Partial");
        sellAllItem.addActionListener(e -> sellAll());
        sellPartItem.addActionListener(e -> sellPartial());
        sellMenu.add(sellAllItem);
        sellMenu.add(sellPartItem);
        sellMenuBtn.addActionListener(e -> sellMenu.show(sellMenuBtn, 0, sellMenuBtn.getHeight()));
        
        nextBtn = new JButton("Next Day");
        nextBtn.addActionListener(e -> updatePrice());
        infoBtn = new JButton("View Info");
        infoBtn.addActionListener(e -> showUserInfo());
        priceBtn = new JButton("View Prices");
        priceBtn.addActionListener(e -> showPrices());
        
        logBtn = new JButton("Transaction record");
        logBtn.addActionListener(e -> {
            try {
                toServer.writeUTF("GET_LOG");
                int count = fromServer.readInt();
                StringBuilder sb = new StringBuilder("Transaction record：\n");
                for (int i = 0; i < count; i++) {
                    sb.append(fromServer.readUTF()).append("\n");
                }
                JOptionPane.showMessageDialog(Client.this, sb.toString(), "Transaction record", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        
        chartBtn = new JButton("View Chart");
        chartBtn.addActionListener(e -> showChart(selectedStock));
        compareChartBtn = new JButton("Compare Charts");
        compareChartBtn.addActionListener(e -> showComparisonChart());
        
        topPanel.add(logBtn);
        topPanel.add(buyMenuBtn);
        topPanel.add(sellMenuBtn);
        topPanel.add(nextBtn);
        topPanel.add(infoBtn);
        topPanel.add(priceBtn);
        topPanel.add(chartBtn);
        topPanel.add(compareChartBtn);
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(ta), BorderLayout.CENTER);
        

        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    private void loginOrRegister() {
        String[] options = {"Login", "Register"};
        int choice = JOptionPane.showOptionDialog(this, "Choose Action", "Login/Register",
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        
        if (choice == -1) {
            JOptionPane.showMessageDialog(this, "You must choose Login or Register.");
            System.exit(0);
        }
        
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");

        try {
            toServer.writeUTF(choice == 0 ? "LOGIN" : "REGISTER");
            toServer.writeUTF(username);
            toServer.writeUTF(password);

            boolean success = fromServer.readBoolean();
            if (!success) {
                JOptionPane.showMessageDialog(this, "Authentication failed. Closing app.");
                System.exit(0);
            } else {
            	this.username = username; // 保存用户名
            	this.setTitle("Stock Client - User: " + username); // 设置窗口标题
            	this.cash = fromServer.readDouble();
           
                Gson gson = new Gson();
                java.lang.reflect.Type type = new TypeToken<Map<String, Integer>>() {}.getType();
                holdings = gson.fromJson(fromServer.readUTF(), type);
                if (holdings == null) holdings = new HashMap<>();
                while (true) {
                    String stock = fromServer.readUTF();
                    if ("END".equals(stock)) break;
                    double price = fromServer.readDouble();
                    stockPrices.put(stock, price);
                    
                }
                
                for (String stock : stockPrices.keySet()) {
                    toServer.writeUTF("GET_HISTORY " + stock);
                    int len = fromServer.readInt();
                    List<Double> history = new ArrayList<>();
                    for (int i = 0; i < len; i++) {
                        history.add(fromServer.readDouble());
                    }
                    stockHistory.put(stock, history);  // ✅ 保存历史记录
                }
                
                //初始化股票列表
                stockSelector.setModel(new DefaultComboBoxModel<>(stockPrices.keySet().toArray(new String[0])));
                selectedStock = (String) stockSelector.getSelectedItem();
                
                for (String stock : stockPrices.keySet()) {
                    toServer.writeUTF("GET_HISTORY " + stock);
                    int len = fromServer.readInt();
                    List<Double> history = new ArrayList<>();
                    for (int i = 0; i < len; i++) {
                        history.add(fromServer.readDouble());
                    }
                    stockHistory.put(stock, history);
                }
                
                ta.append(String.format("Welcome %s! Cash: $%.2f, Holdings: %s\n",
                    username, cash, holdings));
                
                ta.append("Initial prices:\n");
                for (String stock : stockPrices.keySet()) {
                    ta.append(String.format(" - %s: $%.2f\n", stock, stockPrices.get(stock)));
                }
                
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Connection error during login.");
            System.exit(0);
        }
    }
    
    private void connectToServer() {
        try {
            Socket socket = new Socket("localhost", 8000);
            toServer = new DataOutputStream(socket.getOutputStream());
            fromServer = new DataInputStream(socket.getInputStream());
            loginOrRegister();
            // 初始读取服务器发送的当前股价
            //currentPrice = fromServer.readDouble();
            //ta.append("Current stock price: $" + currentPrice + "\n");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Connection to server fails");
        }
    }
    
    private void updateUserInfoFromServer() throws IOException {
        Gson gson = new Gson();
        java.lang.reflect.Type type = new TypeToken<Map<String, Object>>() {}.getType();
        Map<String, Object> data = gson.fromJson(fromServer.readUTF(), type);
        cash = ((Number) data.get("cash")).doubleValue();
        Map<String, Double> rawHoldings = (Map<String, Double>) data.get("holdings");
        holdings.clear();
        for (Map.Entry<String, Double> e : rawHoldings.entrySet()) {
            holdings.put(e.getKey(), e.getValue().intValue());
        }
    }
    
    private void buyAll() {
    	if (tradingEnded) {
            ta.append("End of transaction！Unable to buy!\n");
            return;
        }
        try {
        	toServer.writeUTF("BUY_ALL " + selectedStock);
            double price = fromServer.readDouble();
            updateUserInfoFromServer();
            int amount = holdings.getOrDefault(selectedStock, 0);
            ta.append(String.format("[%s] Bought ALL %d %s @ $%.2f\n", username, amount, selectedStock, price));
            updateBalance();
            ta.append(String.format("After transaction: Total assets = $%.2f\n", cash + holdings.getOrDefault(selectedStock, 0) * price));
            
        } catch (IOException e) {
            ta.append("Buy failed\n");
        }
    }
    
    private void buyPartial() {
        if (tradingEnded) return;
        String input = JOptionPane.showInputDialog(this, "Enter number of shares to BUY:");
        try {
        	int amount = Integer.parseInt(input);
            toServer.writeUTF("BUY_PARTIAL " + selectedStock);
            toServer.writeInt(amount);
            boolean success = fromServer.readBoolean();
            double price = fromServer.readDouble();
            updateUserInfoFromServer();
            if (success) {
                cash -= amount * price;
                holdings.put(selectedStock, holdings.getOrDefault(selectedStock, 0) + amount);
                ta.append(String.format("[%s] Bought %d %s @ $%.2f\n", username, amount, selectedStock, price));
                updateBalance();
                ta.append(String.format("After transaction: Total assets = $%.2f\n", cash + holdings.getOrDefault(selectedStock, 0) * price));
            } else {
                ta.append("Buy failed\n");
            }
        } catch (Exception e) {
            ta.append("Invalid input.\n");
        }
    }
    
    private void sellAll() {
        try {
        	toServer.writeUTF("SELL_ALL " + selectedStock);
            double price = fromServer.readDouble();
            updateUserInfoFromServer();
            ta.append(String.format("[%s] Sold ALL %s @ $%.2f\n", username, selectedStock, price));
            updateBalance();
            ta.append(String.format("After transaction: Total assets = $%.2f\n", cash + holdings.getOrDefault(selectedStock, 0) * price));
        } catch (IOException e) {
            ta.append("Sell failed\n");
        }
    }
    
    private void sellPartial() {
        if (tradingEnded) return;
        String input = JOptionPane.showInputDialog(this, "Enter number of shares to SELL:");
        try {
        	int amount = Integer.parseInt(input);
            toServer.writeUTF("SELL_PARTIAL " + selectedStock);
            toServer.writeInt(amount);
            boolean success = fromServer.readBoolean();
            double price = fromServer.readDouble();
            updateUserInfoFromServer();
            if (success) {
                cash += amount * price;
                holdings.put(selectedStock, holdings.getOrDefault(selectedStock, 0) - amount);
                ta.append(String.format("[%s] Sold %d %s @ $%.2f\n", username, amount, selectedStock, price));
                updateBalance();
                ta.append(String.format("After transaction: Total assets = $%.2f\n", cash + holdings.getOrDefault(selectedStock, 0) * price));
            } else {
                ta.append("Sell failed\n");
            }
        } catch (Exception e) {
            ta.append("Invalid input.\n");
        }
    }
    
    
    private void showUserInfo() {
    	try {
            toServer.writeUTF("GET_USER_INFO");
            updateUserInfoFromServer();
        } catch (IOException e) {
            ta.append("Failed to fetch user info.\n");
        }
        ta.append(String.format("[%s] Cash: $%.2f\n", username, cash));
        for (String stock : stockPrices.keySet()) {
            int s = holdings.getOrDefault(stock, 0);
            double p = stockPrices.get(stock);
            try {
                toServer.writeUTF("GET_AVG_PRICE " + stock);
                double avg = fromServer.readDouble();
                double pnl = (p - avg) * s;
                ta.append(String.format(" - %s: %d shares @ $%.2f (avg $%.2f) = $%.2f | PnL: $%.2f\n",
                    stock, s, p, avg, s * p, pnl));
            } catch (IOException ex) {
                ta.append(String.format(" - %s: %d shares @ $%.2f = $%.2f\n", stock, s, p, s * p));
            }
        }
    }
    
    private void refreshPricesFromServer() throws IOException {
        toServer.writeUTF("GET_PRICES");
        stockPrices.clear();
        while (true) {
            String stock = fromServer.readUTF();
            if ("END".equals(stock)) break;
            double price = fromServer.readDouble();
            stockPrices.put(stock, price);
        }
    }
    
    private void showPrices() {
    	try {
            refreshPricesFromServer();  
            ta.append("Current Stock Prices:\n");
            for (Map.Entry<String, Double> entry : stockPrices.entrySet()) {
                ta.append(String.format(" - %s: $%.2f\n", entry.getKey(), entry.getValue()));
            }
        } catch (IOException e) {
            ta.append("❌ Failed to fetch updated prices\n");
            e.printStackTrace();
        }
    }
    
    private void updatePrice() {
    	if (tradingEnded) {
            ta.append("End of transaction！Unable to update!\n");
            return;
        }
        try {
        	toServer.writeUTF("NEXT");
        	Map<String, Double> oldPrices = new HashMap<>(stockPrices);
        	ta.append(" Market advanced to next day:\n");
        	while (true) {
        	    String stock = fromServer.readUTF();
        	    if ("END".equals(stock)) break;
        	    double newPrice = fromServer.readDouble();
                double oldPrice = oldPrices.getOrDefault(stock, newPrice);
                stockPrices.put(stock, newPrice);
                stockHistory.putIfAbsent(stock, new ArrayList<>());
                stockHistory.get(stock).add(newPrice);
                
                String trend = "No change";
                if (newPrice > oldPrice) trend = "Up";
                else if (newPrice < oldPrice) trend = "Down";

                ta.append(String.format(" - %s: $%.2f (%s)\n", stock, newPrice, trend));
        	}
            updateBalance();
        } catch (IOException e) {
            tradingEnded = true;
            ta.append("Price update failed\n");
            // End of stock update, disable transaction buttons
        	/*
            ta.append("End of transaction！Unable to operate!\n");
            buyBtn.setEnabled(false);
            sellBtn.setEnabled(false);
            nextBtn.setEnabled(false);
            */
            endTrading();
        }
    }
    
    private void updateBalance() {
    	double price = stockPrices.getOrDefault(selectedStock, 0.0);
        int shares = holdings.getOrDefault(selectedStock, 0);
        double total = shares * price + cash;
        ta.append(String.format("[%s] %s shares: %d, Cash: $%.2f, Total: $%.2f\n",
            username, selectedStock, shares, cash, total));
    }
    
    private void endTrading() {
        tradingEnded = true;
        buyMenuBtn.setEnabled(false);
        sellMenuBtn.setEnabled(false);
        nextBtn.setEnabled(false);
        ta.append("End of transaction！Unable to operate!\\n");
    }
    
    private void saveComponentAsPNG(Component comp, String filename) {
        BufferedImage image = new BufferedImage(
            comp.getWidth(), comp.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        comp.paint(g2);
        g2.dispose();
        try {
            File file = new File("charts");
            if (!file.exists()) file.mkdirs();
            ImageIO.write(image, "png", new File(file, filename));
            ta.append("✅ Chart exported: charts/" + filename + "\n");
        } catch (IOException e) {
            ta.append("❌ Failed to export chart.\n");
        }
    }
    
    private void showChart(String stock) {
    	List<Double> prices = stockHistory.get(stock);
        if (prices == null || prices.size() < 2) {
            JOptionPane.showMessageDialog(this, "Not enough data to display chart.");
            return;
        }

        JFrame chartFrame = new JFrame("Price Chart - " + stock);
        chartFrame.setSize(600, 400);
        chartFrame.setLocationRelativeTo(this);

        JPanel chartPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
            	super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                int chartW = w - 80;
                int chartH = h - 80;

                // 背景渐变
                GradientPaint gradient = new GradientPaint(0, 0, Color.WHITE, 0, h, new Color(240, 245, 255));
                g2.setPaint(gradient);
                g2.fillRect(0, 0, w, h);

                double max = Collections.max(prices), min = Collections.min(prices);
                if (max == min) max += 1;

                int size = prices.size();

                // 画坐标轴
                g2.setColor(Color.GRAY);
                g2.drawLine(40, 40, 40, h - 40);          // Y轴
                g2.drawLine(40, h - 40, w - 20, h - 40);  // X轴

                // 横向网格线
                g2.setColor(new Color(220, 220, 220));
                for (int i = 0; i <= 5; i++) {
                    int y = h - 40 - i * chartH / 5;
                    g2.drawLine(40, y, w - 20, y);
                    double val = min + (max - min) * i / 5;
                    g2.setColor(Color.DARK_GRAY);
                    g2.drawString(String.format("$%.2f", val), 5, y + 5);
                    g2.setColor(new Color(220, 220, 220));
                }

                // 折线图
                g2.setColor(Color.BLUE);
                g2.setStroke(new BasicStroke(2));
                for (int i = 1; i < size; i++) {
                    int x1 = 40 + (i - 1) * chartW / (size - 1);
                    int y1 = h - 40 - (int)((prices.get(i - 1) - min) / (max - min) * chartH);
                    int x2 = 40 + i * chartW / (size - 1);
                    int y2 = h - 40 - (int)((prices.get(i) - min) / (max - min) * chartH);
                    g2.drawLine(x1, y1, x2, y2);
                }

                // 当前价格圆点 + 标注
                g2.setColor(Color.RED);
                int xLast = 40 + (size - 1) * chartW / (size - 1);
                int yLast = h - 40 - (int)((prices.get(size - 1) - min) / (max - min) * chartH);
                g2.fillOval(xLast - 4, yLast - 4, 8, 8);
                g2.drawString(String.format("Latest: $%.2f", prices.get(size - 1)), xLast - 50, yLast - 10);

                // 横坐标 Day 1 ~ Day N
                g2.setColor(Color.DARK_GRAY);
                for (int i = 0; i < size; i++) {
                    int x = 40 + i * chartW / (size - 1);
                    g2.drawString("Day " + (i + 1), x - 10, h - 20);
                }
            }
        };

        chartFrame.add(chartPanel);
        JButton exportBtn = new JButton("Export to PNG");
        exportBtn.addActionListener(e -> saveComponentAsPNG(chartPanel, stock + "_chart.png"));
        chartFrame.add(exportBtn, BorderLayout.SOUTH);
        chartFrame.setVisible(true);
    }

    private void showComparisonChart() {
    	int choice = JOptionPane.showConfirmDialog(this, 
    	        "Use normalized price for comparison?", 
    	        "Chart Option", JOptionPane.YES_NO_OPTION);
    	boolean normalize = (choice == JOptionPane.YES_OPTION);
    	
        JFrame chartFrame = new JFrame("Stock Comparison Chart");
        chartFrame.setSize(800, 500);
        chartFrame.setLocationRelativeTo(this);

        JPanel chartPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                g2.setColor(Color.WHITE);
                g2.fillRect(0, 0, w, h);

                int chartW = w - 100, chartH = h - 80;

                // 计算归一化后的全局最大最小
                double globalMax = Double.MIN_VALUE, globalMin = Double.MAX_VALUE;
                for (List<Double> prices : stockHistory.values()) {
                    if (prices.size() < 2) continue;
                    double base = prices.get(0);
                    for (double p : prices) {
                        double val = normalize ? p / base : p;
                        globalMax = Math.max(globalMax, val);
                        globalMin = Math.min(globalMin, val);
                    }
                }
                if (globalMax == globalMin) globalMax += 1;

                // 准备颜色
                Color[] colors = {Color.BLUE, Color.RED, Color.GREEN, Color.ORANGE, Color.MAGENTA};
                int colorIndex = 0;

                int xOffset = 60, yOffset = 40;
                int stepX = chartW / 20;

                for (String stock : stockHistory.keySet()) {
                    List<Double> prices = stockHistory.get(stock);
                    if (prices.size() < 2) continue;
                    double base = prices.get(0);

                    g2.setColor(colors[colorIndex++ % colors.length]);

                    for (int i = 1; i < prices.size(); i++) {
                        double v1 = normalize ? prices.get(i - 1) / base : prices.get(i - 1);
                        double v2 = normalize ? prices.get(i) / base : prices.get(i);
                        int x1 = xOffset + (i - 1) * stepX;
                        int x2 = xOffset + i * stepX;
                        int y1 = yOffset + (int)((globalMax - v1) / (globalMax - globalMin) * chartH);
                        int y2 = yOffset + (int)((globalMax - v2) / (globalMax - globalMin) * chartH);
                        g2.drawLine(x1, y1, x2, y2);
                    }

                    g2.drawString(stock, xOffset + prices.size() * stepX + 10, yOffset + colorIndex * 20);
                }

                // 画Y坐标标签
                g2.setColor(Color.GRAY);
                for (int i = 0; i <= 5; i++) {
                    double val = globalMin + (globalMax - globalMin) * i / 5;
                    int y = yOffset + (int)((globalMax - val) / (globalMax - globalMin) * chartH);
                    g2.drawLine(xOffset - 5, y, xOffset + chartW, y);
                    g2.drawString(String.format("%.2f", val), 10, y + 5);
                }

                // 画X坐标
                g2.drawLine(xOffset, yOffset + chartH, xOffset + chartW, yOffset + chartH);
                
                g2.setColor(Color.DARK_GRAY);
                int maxSize = stockHistory.values().stream().mapToInt(List::size).max().orElse(0);
                for (int i = 0; i < maxSize; i++) {
                    int x = xOffset + i * stepX;
                    g2.drawString("Day " + (i + 1), x - 10, yOffset + chartH + 20);
                    g2.drawLine(x, yOffset + chartH - 5, x, yOffset + chartH + 5);
                }
            }
        };

        chartFrame.add(chartPanel);
        JPanel buttonPanel = new JPanel();
        JButton exportBtn = new JButton("Export to PNG");
        exportBtn.addActionListener(e -> saveComponentAsPNG(chartPanel, "comparison_chart.png"));
        buttonPanel.add(exportBtn);
        chartFrame.add(buttonPanel, BorderLayout.SOUTH);
        chartFrame.setVisible(true);
    }
    
    public static void main(String[] args) {
        new Client();
    }
}